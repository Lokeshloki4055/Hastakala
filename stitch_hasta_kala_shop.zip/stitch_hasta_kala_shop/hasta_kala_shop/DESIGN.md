---
name: Hasta-Kala Shop
colors:
  surface: '#fbf9f9'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#3d4946'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#6d7a77'
  outline-variant: '#bcc9c5'
  surface-tint: '#006b5f'
  primary: '#00685d'
  on-primary: '#ffffff'
  primary-container: '#008376'
  on-primary-container: '#f4fffb'
  inverse-primary: '#70d8c8'
  secondary: '#8f4e00'
  on-secondary: '#ffffff'
  secondary-container: '#ff8f00'
  on-secondary-container: '#623400'
  tertiary: '#266658'
  on-tertiary: '#ffffff'
  tertiary-container: '#417f70'
  on-tertiary-container: '#f4fffa'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#8df5e4'
  primary-fixed-dim: '#70d8c8'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#005048'
  secondary-fixed: '#ffdcc2'
  secondary-fixed-dim: '#ffb77a'
  on-secondary-fixed: '#2e1500'
  on-secondary-fixed-variant: '#6d3a00'
  tertiary-fixed: '#afefdd'
  tertiary-fixed-dim: '#94d3c1'
  on-tertiary-fixed: '#00201a'
  on-tertiary-fixed-variant: '#065043'
  background: '#fbf9f9'
  on-background: '#1b1c1c'
  surface-variant: '#e3e2e2'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Work Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  margin-mobile: 16px
  gutter-mobile: 16px
  touch-target-min: 48px
---

## Brand & Style

The design system is built to empower rural artisans by bridging the gap between traditional craftsmanship and modern digital commerce. The brand personality is **Trustworthy and Professional**, ensuring artisans feel secure in their business transactions, yet it remains **Grounded and Accessible** to accommodate varying levels of digital literacy.

The visual style is a **Modern-Corporate** hybrid, heavily inspired by Material Design 3. It prioritizes functional clarity over decorative flair, utilizing generous whitespace and a clear visual hierarchy. To celebrate the craft heritage, the UI incorporates subtle organic textures and hand-drawn style icons that resonate with the physical nature of artisanal work. The interface is optimized for outdoor use, ensuring high legibility and ease of interaction under direct sunlight.

## Colors

The palette is anchored by a deep **Teal**, evoking stability and professionalism. This is paired with an **Amber/Gold** accent, representing the value and "preciousness" of handmade goods. 

- **Primary (Teal):** Used for key actions, navigation, and brand-heavy components.
- **Secondary (Amber):** Used sparingly for highlighting special features, badges, or "Call to Action" buttons to ensure they stand out.
- **Backgrounds:** The primary background is pure white to maximize contrast, while the surface tint (#F5F5F5) is used to define distinct sections and card containers.
- **High Visibility:** Text colors maintain a high contrast ratio against backgrounds to ensure readability in bright, rural environments.

## Typography

This design system utilizes a dual-font strategy to balance character with utility. 

**Plus Jakarta Sans** (Primary) is used for all headings and titles. Its geometric yet friendly nature mirrors the "Poppins" aesthetic, providing a professional and contemporary feel. Bold weights are reserved for top-level headings to create a strong visual anchor.

**Work Sans** (Secondary) is used for body copy and labels. Its slightly wider apertures and grounded proportions ensure excellent legibility at smaller sizes and across various screen qualities. All body text should adhere to a minimum of 14px to support accessibility for users with varying eyesight conditions.

## Layout & Spacing

The design system follows a **Fluid Grid** model optimized for Android mobile devices. 

- **Grid:** A 4-column fluid grid for mobile, with 16px outer margins and 16px gutters.
- **Rhythm:** An 8px (0.5rem) base unit governs all spatial relationships. 
- **Touch Targets:** A strict minimum of 48dp is enforced for all interactive elements (buttons, icons, toggles) to accommodate users who may be working with their hands and require larger areas for tap accuracy.
- **Sunlight Visibility:** Spacing is generous to prevent visual clutter, making it easier for users to process information quickly when glare is present.

## Elevation & Depth

This design system utilizes **Tonal Layers** and clean elevation to create hierarchy. 

- **Surfaces:** Depth is primarily communicated through color shifts (e.g., using the Surface Tint to differentiate a card from the background).
- **Shadows:** When used, shadows are "Ambient" and diffused. They should be low-opacity with a subtle Teal tint (#004D40 at 8-12% opacity) to feel more natural and integrated with the brand colors. 
- **Levels:** 
  - **Level 0 (Flat):** Main background.
  - **Level 1 (Raised):** Resting state for cards and floating action buttons (FAB).
  - **Level 2 (Elevated):** Pressed states or active dialogs.

## Shapes

The shape language is approachable and soft, avoiding sharp edges to maintain a "friendly" and "accessible" tone. 

- **Standard Elements:** Buttons and small containers use a 0.5rem (8px) radius.
- **Cards and Dialogs:** A specific 0.75rem (12px) corner radius is applied to all product cards and modal sheets to provide a distinct, professional look that feels substantial and "hand-finished."
- **Inputs:** Text fields use a consistent 8px radius to match the button style, creating a cohesive form-entry experience.

## Components

### Buttons
- **Primary:** Solid Teal background with White text. Minimum height 48dp.
- **Secondary:** Amber background for high-priority marketing actions (e.g., "Feature my Product").
- **Outlined:** Teal border (1.5px) for secondary actions like "Cancel" or "Save Draft."

### Cards
- **Product Cards:** Use the 12dp rounded corner. Include a subtle 1px border (#E0E0E0) for definition in bright light. 
- **Artisan Profile Cards:** Feature a circular avatar and craft-themed background patterns.

### Form Inputs
- **Text Fields:** Outlined style with a 1.5px border. Labels must always be visible (not just placeholders) to ensure users don't lose context.
- **Checkboxes/Radios:** Large hit-states (48dp) with high-contrast Teal fills when selected.

### Icons & Emojis
- **Craft-Themed Icons:** Use custom icons for categories like "Weaving" 🧶, "Pottery" 🏺, and "Woodwork" 🪵. 
- **Style:** Icons should have a consistent stroke weight and slightly rounded terminals to match the typography.

### Lists
- Use high-contrast dividers (#E0E0E0) between items.
- List items must have a minimum height of 56dp for easy scrolling and selection.